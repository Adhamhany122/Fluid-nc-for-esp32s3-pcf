// Copyright (c) 2022 - Mitch Bradley
// Use of this source code is governed by a GPLv3 license that can be found in the LICENSE file.

#include "Config.h"
#if MAX_N_I2C
#    include "I2CBus.h"
#    include "Driver/fluidnc_i2c.h"
#    include "NutsBolts.h"  // get_ms()
#    include "string_util.h"  // to_hex()

namespace Machine {
    I2CBus::I2CBus(objnum_t busNumber) : _busNumber(busNumber) {}

    void I2CBus::validate() {
        if (_sda.defined() || _scl.defined()) {
            Assert(_sda.defined(), "I2C SDA pin configured multiple times");
            Assert(_scl.defined(), "I2C SCL pin configured multiple times");
        }
    }

    void I2CBus::group(Configuration::HandlerBase& handler) {
        // @config sda_pin
        // @default NO_PIN
        // @pin_attributes i2c
        // I2C data line for this bus.
        handler.item("sda_pin", _sda);

        // @config scl_pin
        // @default NO_PIN
        // @pin_attributes i2c
        // I2C clock line for this bus.
        handler.item("scl_pin", _scl);

        // @config frequency
        // @default 100000
        // I2C bus clock frequency, in Hz (100000 = standard-mode I2C, 100kHz).
        handler.item("frequency", _frequency);
    }

    void I2CBus::init() {
        _error      = false;
        auto sdaPin = _sda.getNative(Pin::Capabilities::Native | Pin::Capabilities::Input | Pin::Capabilities::Output);
        auto sclPin = _scl.getNative(Pin::Capabilities::Native | Pin::Capabilities::Input | Pin::Capabilities::Output);

        log_info("I2C SDA: " << _sda.name() << ", SCL: " << _scl.name() << ", Freq: " << _frequency << ", Bus #: " << _busNumber);

        if (!_mutex) {
            _mutex = xSemaphoreCreateMutex();
        }
        _sdaNum = sdaPin;
        _sclNum = sclPin;
        _error  = i2c_master_init(_busNumber, sdaPin, sclPin, _frequency);
        if (_error) {
            log_error("I2C init failed");
        }

#    if SCAN_I2C_BUS
        // This should be a command instead of something that happens automatically on init
        objnum_t nDevices = 0;
        log_info("Scanning...");
        for (uint8_t address = 1; address < 127; address++) {
            uint8_t buf[1];
            auto    error = i2c_write(_busNumber, address, buf, 0);
            if (error == 0) {
                log_info("I2C device found at address " << int(address));
                nDevices++;
            }
        }
        if (nDevices == 0) {
            log_info("No I2C devices found");
        } else {
            log_info("done");
        }
#    endif
    }

    void I2CBus::recover() {
        if (!_mutex) {
            return;
        }
        xSemaphoreTake(_mutex, portMAX_DELAY);
        _error = i2c_master_init(_busNumber, (pinnum_t)_sdaNum, (pinnum_t)_sclNum, _frequency);
        xSemaphoreGive(_mutex);
        log_info("I2C bus re-initialized (recovery)");
    }

    // Transient failures (bus glitches, ISR latency while WiFi/flash activity is
    // going on) are retried before they are reported.
    static const int kI2CAttempts = 3;

    int I2CBus::write(uint8_t address, const uint8_t* data, size_t count) {
        if (_error) {
            return -1;
        }

        log_verbose("I2C write: " << int(address); for (int i = 0; i < count; ++i) { ss << ' ' << int(data[i]); });

        int ret = -1;
        for (int attempt = 0; attempt < kI2CAttempts; ++attempt) {
            if (_mutex) {
                xSemaphoreTake(_mutex, portMAX_DELAY);
            }
            ret = i2c_write(_busNumber, address, data, count);
            if (_mutex) {
                xSemaphoreGive(_mutex);
            }
            if (ret == (int)count) {
                return ret;
            }
            vTaskDelay(pdMS_TO_TICKS(2));
        }

        // All attempts failed. Rate-limit the warning.
        uint32_t now = get_ms();
        if (now - _lastWarnMs > 2000) {
            log_warn("I2C write to " << to_hex(address) << " failed (" << ret << "), " << _suppressedWarn << " similar warnings suppressed");
            _lastWarnMs     = now;
            _suppressedWarn = 0;
        } else {
            ++_suppressedWarn;
        }
        return ret;
    }

    int I2CBus::read(uint8_t address, uint8_t* data, size_t count) {
        if (_error) {
            return -1;
        }
        log_verbose("I2C read: " << int(address));
        int ret = 0;
        for (int attempt = 0; attempt < kI2CAttempts; ++attempt) {
            if (_mutex) {
                xSemaphoreTake(_mutex, portMAX_DELAY);
            }
            ret = i2c_read(_busNumber, address, data, count);
            if (_mutex) {
                xSemaphoreGive(_mutex);
            }
            if (ret == (int)count) {
                return ret;
            }
            vTaskDelay(pdMS_TO_TICKS(2));
        }
        return ret;
    }
}
#endif
