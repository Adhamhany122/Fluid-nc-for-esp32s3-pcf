#include "PCF8574Keypad.h"

#include "Machine/MachineConfig.h"
#include "Machine/I2CBus.h"
#include "PowerLossRecovery.h"
#include "RealtimeCmd.h"
#include "Settings.h"   // execute_line
#include "Serial.h"     // allChannels
#include "NutsBolts.h"  // get_ms()
#include "Logging.h"
#include "string_util.h"  // to_hex()
#include "OLEDNotify.h"

#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <cstdio>
#include <cstring>

namespace {

    // PCF8574 bit assignment -- see the wiring table in PCF8574Keypad.h.
    constexpr uint8_t kRowBits[3] = { 0, 1, 2 };
    constexpr uint8_t kColBits[4] = { 3, 4, 5, 6 };

    enum class KeyAction : uint8_t {
        JogXNeg,
        JogXPos,
        JogYPos,
        JogZPos,
        JogYNeg,
        JogZNeg,
        Home,
        Reset,
        FeedHold,
        CycleStart,
        Start,
        Stop,
        None,
    };

    // [row][col] where row = PCF P0-P2 (driven low) and col = PCF P3-P6 (read).
    // Matches the user's tested wiring: P0-P2 are the 3 keypad columns, P3-P6 the 4 keypad rows.
    //   P3-P6 row:   X-  X+  Y+  /  Y-  Z+  Z-  /  HOME RESET FEED_HOLD  /  CYCLE_START START STOP
    constexpr KeyAction kKeyMap[3][4] = {
        { KeyAction::JogXNeg, KeyAction::JogYNeg, KeyAction::Home, KeyAction::CycleStart },
        { KeyAction::JogXPos, KeyAction::JogZPos, KeyAction::Reset, KeyAction::Start },
        { KeyAction::JogYPos, KeyAction::JogZNeg, KeyAction::FeedHold, KeyAction::Stop },
    };

    bool isJogAction(KeyAction a) {
        switch (a) {
            case KeyAction::JogXNeg:
            case KeyAction::JogXPos:
            case KeyAction::JogYPos:
            case KeyAction::JogYNeg:
            case KeyAction::JogZPos:
            case KeyAction::JogZNeg:
                return true;
            default:
                return false;
        }
    }

    void jogAxisAndSign(KeyAction a, char& axis, int& sign) {
        switch (a) {
            case KeyAction::JogXNeg:
                axis = 'X';
                sign = -1;
                break;
            case KeyAction::JogXPos:
                axis = 'X';
                sign = 1;
                break;
            case KeyAction::JogYPos:
                axis = 'Y';
                sign = 1;
                break;
            case KeyAction::JogYNeg:
                axis = 'Y';
                sign = -1;
                break;
            case KeyAction::JogZPos:
                axis = 'Z';
                sign = 1;
                break;
            case KeyAction::JogZNeg:
                axis = 'Z';
                sign = -1;
                break;
            default:
                axis = '?';
                sign = 0;
                break;
        }
    }

    struct ScanContext {
        Machine::I2CBus* i2c;
        uint8_t           address;
        uint32_t          debounce_ms;
        uint32_t          repeat_ms;
        float             jog_step_mm;
        float             jog_feed;
        float             jog_step_a;       // step for the A axis (degrees)
        float             jog_feed_a;       // feed for the A axis (deg/min)
        float             jog_continuous;   // distance of a "hold" jog (cancelled on release)
        uint32_t          long_press_ms;    // hold time before a jog becomes continuous
        uint32_t          stop_confirm_ms;  // window for the second STOP press
    };

    bool scanRow(ScanContext& ctx, int row, uint8_t& colBits) {
        uint8_t out = 0xFF & ~(1 << kRowBits[row]);  // drive this row low, leave everything else high
        if (ctx.i2c->write(ctx.address, &out, 1) < 0) {
            return false;
        }
        uint8_t in = 0xFF;
        if (ctx.i2c->read(ctx.address, &in, 1) != 1) {
            return false;
        }
        colBits = in;
        return true;
    }

    void releaseAllRows(ScanContext& ctx) {
        uint8_t out = 0xFF;
        ctx.i2c->write(ctx.address, &out, 1);
    }

    uint32_t g_stopConfirmMs = 2000;

    // ---- state shared by the helpers below (only the keypad task touches these) ----
    bool     g_zIsA          = false;  // Z+/Z- currently drive the A axis
    uint32_t g_stopPendingUntil = 0;   // STOP needs a second press before this time

    const char* keyName(KeyAction a) {
        switch (a) {
            case KeyAction::JogXNeg: return "X-";
            case KeyAction::JogXPos: return "X+";
            case KeyAction::JogYNeg: return "Y-";
            case KeyAction::JogYPos: return "Y+";
            case KeyAction::JogZNeg: return g_zIsA ? "A-" : "Z-";
            case KeyAction::JogZPos: return g_zIsA ? "A+" : "Z+";
            case KeyAction::Home: return "HOME";
            case KeyAction::Reset: return "RESET";
            case KeyAction::FeedHold: return "FEED HOLD";
            case KeyAction::CycleStart: return "CYCLE START";
            case KeyAction::Start: return "START";
            case KeyAction::Stop: return "STOP";
            default: return "";
        }
    }

    // One-shot actions: realtime commands and $H. Never called for jog actions.
    void fireAction(KeyAction a, uint32_t now) {
        if (PLR::promptPending()) {
            // Start/Stop double as the Yes/No answer to the resume prompt, and
            // Home is allowed (resume needs a homed machine). Every other key
            // is ignored so a stray press can't jog or start a cycle before
            // the operator has answered.
            if (a == KeyAction::Start) {
                PLR::confirmResume();
            } else if (a == KeyAction::Stop) {
                PLR::cancelResume();
            } else if (a == KeyAction::Home) {
                execute_line("$H", allChannels, AuthenticationLevel::LEVEL_ADMIN, false);
            }
            return;
        }

        switch (a) {
            case KeyAction::Home:
                oled_notify_key(keyName(a), 1500);
                execute_line("$H", allChannels, AuthenticationLevel::LEVEL_ADMIN, false);
                break;
            case KeyAction::Reset:
                oled_notify_key(keyName(a), 1500);
                execute_realtime_command(Cmd::Reset, allChannels);
                break;
            case KeyAction::Stop:
                // STOP needs two presses within the confirmation window.
                if ((int32_t)(g_stopPendingUntil - now) > 0) {
                    g_stopPendingUntil = 0;
                    oled_notify_key("STOPPED", 1500);
                    execute_realtime_command(Cmd::Reset, allChannels);
                } else {
                    g_stopPendingUntil = now + (g_stopConfirmMs ? g_stopConfirmMs : 2000);
                    oled_notify_key("STOP? press again", g_stopConfirmMs ? g_stopConfirmMs : 2000);
                }
                break;
            case KeyAction::FeedHold:
                oled_notify_key(keyName(a), 1500);
                execute_realtime_command(Cmd::FeedHold, allChannels);
                break;
            case KeyAction::CycleStart:
            case KeyAction::Start:
                oled_notify_key(keyName(a), 1500);
                execute_realtime_command(Cmd::CycleStart, allChannels);
                break;
            default:
                break;
        }
    }

    // Jog axis letter for a jog key, honouring the Z/A switch.
    char jogAxisFor(KeyAction a, int& sign) {
        char axis;
        jogAxisAndSign(a, axis, sign);
        if (axis == 'Z' && g_zIsA) {
            axis = 'A';
        }
        return axis;
    }

    // Short press: one fixed step, fired immediately on press.
    void fireJogStep(KeyAction a, ScanContext& ctx) {
        if (PLR::promptPending()) {
            return;
        }
        int  sign;
        char axis = jogAxisFor(a, sign);
        float step = (axis == 'A') ? ctx.jog_step_a : ctx.jog_step_mm;
        float feed = (axis == 'A') ? ctx.jog_feed_a : ctx.jog_feed;
        char line[64];
        snprintf(line, sizeof(line), "$J=G91 %c%.3f F%.1f", axis, sign * step, (double)feed);
        oled_notify_key(keyName(a), 1500);
        execute_line(line, allChannels, AuthenticationLevel::LEVEL_ADMIN, false);
    }

    // Long press: a long jog that is cancelled when the key is released.
    void fireJogContinuous(KeyAction a, ScanContext& ctx) {
        if (PLR::promptPending()) {
            return;
        }
        int  sign;
        char axis = jogAxisFor(a, sign);
        float feed = (axis == 'A') ? ctx.jog_feed_a : ctx.jog_feed;
        char line[64];
        snprintf(line, sizeof(line), "$J=G91 %c%.1f F%.1f", axis, sign * ctx.jog_continuous, (double)feed);
        char msg[24];
        snprintf(msg, sizeof(msg), "%s >>", keyName(a));
        oled_notify_key(msg, 1500);
        execute_line(line, allChannels, AuthenticationLevel::LEVEL_ADMIN, false);
    }

    void fireJogStop() { execute_realtime_command(Cmd::JogCancel, allChannels); }

    // Z+ and Z- pressed together: switch the Z keys between the Z and A axes.
    void toggleZA() {
        g_zIsA = !g_zIsA;
        oled_set_zkey_axis(g_zIsA ? 'A' : 'Z');
        oled_notify_key(g_zIsA ? "Z keys -> A" : "Z keys -> Z", 1500);
    }

    constexpr uint16_t kZChord = (1u << (1 * 4 + 1)) | (1u << (2 * 4 + 1));  // Z+ (row1,col1) + Z- (row2,col1)

    void keypadTask(void* arg) {
        auto ctx = static_cast<ScanContext*>(arg);
        g_stopConfirmMs = ctx->stop_confirm_ms;

        // At cold power-up the PCF8574 / bus may not be settled yet.
        vTaskDelay(pdMS_TO_TICKS(500));
        releaseAllRows(*ctx);  // ensure a known idle state (all rows high) before the first scan

        uint32_t fail_count    = 0;
        uint16_t cur_mask      = 0;  // keys currently seen (bit = row*4+col), debounced below
        uint32_t stable_since  = 0;
        uint32_t press_time    = 0;
        bool     confirmed     = false;
        bool     continuous    = false;  // the held jog key has switched to a continuous jog
        bool     chord_done    = false;
        KeyAction held         = KeyAction::None;

        for (;;) {
            vTaskDelay(pdMS_TO_TICKS(20));

            uint16_t mask  = 0;
            bool     io_ok = true;
            for (int row = 0; row < 3; ++row) {
                uint8_t colBits;
                if (!scanRow(*ctx, row, colBits)) {
                    io_ok = false;
                    break;  // device not answering -- do not hammer the bus
                }
                for (int col = 0; col < 4; ++col) {
                    if (!(colBits & (1 << kColBits[col]))) {  // active-low: this key is pressed
                        mask |= (uint16_t)(1u << (row * 4 + col));
                    }
                }
            }
            if (!io_ok) {
                // Transient I2C errors are ignored: keep the previous key state and
                // try again on the next tick. Only a sustained outage is reported.
                ++fail_count;
                if (fail_count == 25) {
                    if (continuous) {
                        fireJogStop();  // lost contact while jogging: stop for safety
                    }
                    cur_mask   = 0;
                    confirmed  = false;
                    continuous = false;
                    held       = KeyAction::None;
                    log_warn("Keypad: PCF8574 @ " << to_hex(ctx->address) << " not responding (check wiring, 3.3V supply, address)");
                }
                if (fail_count >= 25) {
                    if (fail_count % 25 == 0) {
                        ctx->i2c->recover();  // clear a stuck bus and re-init Wire, then keep trying
                    }
                    vTaskDelay(pdMS_TO_TICKS(200));  // slow down while the device is really gone
                }
                continue;
            }
            if (fail_count >= 25) {
                log_info("Keypad: PCF8574 @ " << to_hex(ctx->address) << " is responding again");
            }
            fail_count = 0;
            releaseAllRows(*ctx);

            uint32_t now = get_ms();

            if (mask != cur_mask) {
                // Any change: finish whatever the previous key was doing, restart debounce.
                if (continuous) {
                    fireJogStop();
                }
                cur_mask     = mask;
                stable_since = now;
                confirmed    = false;
                continuous   = false;
                chord_done   = false;
                held         = KeyAction::None;
                continue;
            }
            if (cur_mask == 0) {
                continue;  // nothing pressed
            }

            if (!confirmed) {
                if (now - stable_since < ctx->debounce_ms) {
                    continue;  // still settling
                }
                confirmed  = true;
                press_time = now;
                if (cur_mask == kZChord) {
                    toggleZA();
                    chord_done = true;
                } else if ((cur_mask & (cur_mask - 1)) == 0) {  // exactly one key
                    int bit = 0;
                    while (!(cur_mask & (1u << bit))) {
                        ++bit;
                    }
                    held = kKeyMap[bit / 4][bit % 4];
                    if (isJogAction(held)) {
                        fireJogStep(held, *ctx);
                    } else {
                        fireAction(held, now);
                    }
                }
                // any other combination is ignored (ghost / accidental multi-press)
                continue;
            }

            // key(s) held: a held jog key becomes a continuous jog after long_press_ms
            if (!chord_done && held != KeyAction::None && isJogAction(held) && !continuous && (now - press_time >= ctx->long_press_ms)) {
                continuous = true;
                fireJogContinuous(held, *ctx);
            }
        }
    }
}

void PCF8574Keypad::group(Configuration::HandlerBase& handler) {
    // @config i2c_num
    // @default 0
    // Which top-level i2cN: bus the keypad is wired to.
    handler.item("i2c_num", _i2c_num);

    // @config i2c_address
    // @default 0x20
    // PCF8574 address (0x20-0x27 on the base part with A0-A2 strapped; 0x38-0x3F on the
    // PCF8574A variant). Must match how the module's address pins are strapped.
    handler.item("i2c_address", _address);

    // @config debounce_ms
    // @default 30
    // How long a key must read consistently pressed before it is acted on.
    handler.item("debounce_ms", _debounce_ms, 5, 200);

    // @config repeat_ms
    // @default 120
    // While a jog key (X+/X-/Y+/Y-/Z+/Z-) is held past debounce_ms, a new incremental jog
    // command is issued every repeat_ms. Action keys (Home/Reset/Feed Hold/Cycle
    // Start/Start/Stop) are one-shot and are not affected by this.
    handler.item("repeat_ms", _repeat_ms, 30, 1000);

    // @config jog_step_mm
    // @default 1.0
    // Distance, in mm, moved per jog repeat while a jog key is held.
    handler.item("jog_step_mm", _jog_step_mm, 0.01f, 50.0f);

    // @config jog_feed_mm_per_min
    // @default 800.0
    handler.item("jog_feed_mm_per_min", _jog_feed, 1.0f, 20000.0f);

    // @config long_press_ms
    // @default 400
    // A jog key held longer than this switches from a single step to a continuous jog
    // that stops when the key is released.
    handler.item("long_press_ms", _long_press_ms, 150, 3000);

    // @config jog_step_a_deg
    // @default 1.0
    // Step, in degrees, of a short press while the Z keys are switched to the A axis.
    handler.item("jog_step_a_deg", _jog_step_a, 0.01f, 360.0f);

    // @config jog_feed_a_deg_per_min
    // @default 600.0
    // Feed rate for A-axis jogs.
    handler.item("jog_feed_a_deg_per_min", _jog_feed_a, 1.0f, 20000.0f);

    // @config jog_continuous_mm
    // @default 1000.0
    // Distance requested for a held (continuous) jog. It is cancelled on key release,
    // so this only has to be longer than the axis travel. With soft limits enabled keep
    // it within the travel, or the controller will reject the jog.
    handler.item("jog_continuous_mm", _jog_continuous, 1.0f, 100000.0f);

    // @config stop_confirm_ms
    // @default 2000
    // STOP must be pressed twice within this time to take effect.
    handler.item("stop_confirm_ms", _stop_confirm_ms, 500, 10000);

    // @config enabled
    // @default true
    handler.item("enabled", _enabled);
}

void PCF8574Keypad::validate() {}

void PCF8574Keypad::afterParse() {
    // i2c_num has no YAML-level upper bound (see group() -- it's taken as a
    // plain uint8_t), so a typo'd value must be checked against the real
    // bus count before it is used to index config->_i2c[], or an
    // out-of-range value reads out of bounds.
    if (_i2c_num >= MAX_N_I2C) {
        log_config_error("keypad: i2c_num " << int(_i2c_num) << " is out of range (this board has " << MAX_N_I2C << " I2C bus(es))");
        _error = true;
        return;
    }
    if (!config->_i2c[_i2c_num]) {
        log_config_error("keypad: i2c" << _i2c_num << " section must be defined");
        _error = true;
    }
}

void PCF8574Keypad::init() {
    if (_error || !_enabled) {
        return;
    }

    // DIAGNOSTIC: list every device FluidNC's own I2C bus can see, so a
    // missing/NACKing PCF8574 shows up in the boot log with its real address.
    {
        auto bus   = config->_i2c[_i2c_num];
        int  found = 0;
        for (uint8_t a = 0x08; a < 0x78; ++a) {
            uint8_t dummy = 0xFF;
            if (bus->write(a, &dummy, 0) == 0) {
                log_info("Keypad I2C scan: device found at " << to_hex(a));
                ++found;
            }
        }
        if (!found) {
            log_warn("Keypad I2C scan: NO devices answered on i2c" << int(_i2c_num));
        }
        log_info("Keypad: configured address is " << to_hex(_address) << " (decimal " << int(_address) << ")");
    }

    static ScanContext ctx;  // outlives init(); the task holds a pointer to it
    ctx.i2c         = config->_i2c[_i2c_num];
    ctx.address     = _address;
    ctx.debounce_ms = (uint32_t)_debounce_ms;
    ctx.repeat_ms   = (uint32_t)_repeat_ms;
    ctx.jog_step_mm = _jog_step_mm;
    ctx.jog_feed    = _jog_feed;
    ctx.jog_step_a      = _jog_step_a;
    ctx.jog_feed_a      = _jog_feed_a;
    ctx.jog_continuous  = _jog_continuous;
    ctx.long_press_ms   = (uint32_t)_long_press_ms;
    ctx.stop_confirm_ms = (uint32_t)_stop_confirm_ms;

    xTaskCreatePinnedToCore(keypadTask, "keypad_scan", 4096, &ctx, 3, nullptr, 1);

    log_info("Keypad: PCF8574 @ " << to_hex(_address) << " on i2c" << _i2c_num);
}

void PCF8574Keypad::deinit() {}

ConfigurableModuleFactory::InstanceBuilder<PCF8574Keypad> __keypad_module("keypad");
