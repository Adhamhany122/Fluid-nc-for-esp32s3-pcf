// Small bridge so other modules (keypad) can put short messages on the OLED
// without depending on the OLED class.
#pragma once
#include <cstdint>

// Show msg in the top-right corner of the OLED for duration_ms.
void oled_notify_key(const char* msg, uint32_t duration_ms);
// Tell the OLED which axis the Z+/Z- keys currently control ('Z' or 'A').
void oled_set_zkey_axis(char axis);
