// Copyright 2025 - Mitch Bradley
// Use of this source code is governed by a GPLv3 license that can be found in the LICENSE file.

#include "Platform.h"
#if USE_ARDUINO_I2C_DRIVER
#    include <Wire.h>
#    include "Driver/fluidnc_i2c.h"

// A slave that saw a glitch while the ESP was booting/powering up can be left
// holding SDA low in the middle of a byte. Clock SCL up to 9 times until SDA is
// released, then issue a STOP, so the following Wire.begin() starts from an idle bus.
static void i2c_bus_clear(int sda, int scl) {
    pinMode(sda, INPUT_PULLUP);
    pinMode(scl, INPUT_PULLUP);
    delayMicroseconds(10);
    if (digitalRead(sda) == LOW) {
        pinMode(scl, OUTPUT_OPEN_DRAIN);
        for (int i = 0; i < 9 && digitalRead(sda) == LOW; ++i) {
            digitalWrite(scl, LOW);
            delayMicroseconds(5);
            digitalWrite(scl, HIGH);
            delayMicroseconds(5);
        }
    }
    // STOP condition: SDA low -> high while SCL is high
    pinMode(scl, OUTPUT_OPEN_DRAIN);
    pinMode(sda, OUTPUT_OPEN_DRAIN);
    digitalWrite(sda, LOW);
    delayMicroseconds(5);
    digitalWrite(scl, HIGH);
    delayMicroseconds(5);
    digitalWrite(sda, HIGH);
    delayMicroseconds(5);
}

bool i2c_master_init(objnum_t bus_number, pinnum_t sda_pin, pinnum_t scl_pin, uint32_t frequency) {
    static bool started[2] = { false, false };
    TwoWire&    i2c        = bus_number ? Wire1 : Wire;
    if (started[bus_number ? 1 : 0]) {
        i2c.end();  // re-init (bus recovery): release the pins first
    }
    i2c_bus_clear(int(sda_pin), int(scl_pin));
    // The OLED sends 129 bytes (control byte + 128 pixels) per transaction; the
    // default Wire buffer is 128, which silently drops the last byte. Must be
    // called before begin().
    i2c.setBufferSize(256);
    // Wire.begin() returns false on failure; the old code ignored it and
    // every later write then failed silently with -4.
    bool ok                    = i2c.begin(int(sda_pin), int(scl_pin), frequency);
    started[bus_number ? 1 : 0] = ok;
    return !ok;
};
int i2c_write(objnum_t bus_number, uint8_t address, const uint8_t* data, size_t count) {
    TwoWire& i2c = bus_number ? Wire1 : Wire;

    i2c.beginTransmission(address);
    for (size_t i = 0; i < count; ++i) {
        i2c.write(data[i]);
    }
    auto res = i2c.endTransmission();  // i2c_err_t, see header file
    return res ? -res : count;
}
int i2c_read(objnum_t bus_number, uint8_t address, uint8_t* data, size_t count) {
    TwoWire& i2c    = bus_number ? Wire1 : Wire;
    size_t   actual = i2c.requestFrom((int)address, count);

    for (size_t i = 0; i < actual; ++i) {
        data[i] = i2c.read();
    }
    return actual;
}
#endif
