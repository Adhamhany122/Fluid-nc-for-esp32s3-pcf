// Copyright (c) 2020 -	Bart Dring
// Copyright (c) 2020 -	Stefan de Bruijn
// Use of this source code is governed by a GPLv3 license that can be found in the LICENSE file.

/*
    This is for a VFD based spindles via RS485 Modbus. The details of the 
    VFD protocol heavily depend on the VFD in question here. We have some 
    implementations, but if yours is not here, the place to start is the 
    manual. This VFD class implements the modbus functionality.

                         WARNING!!!!
    VFDs are very dangerous. They have high voltages and are very powerful
    Remove power before changing bits.

    TODO:
      - We can report spindle_state and rpm better with VFD's that support 
        either mode, register RPM or actual RPM.
      - Destructor should break down the task.

*/
#include "VFDSpindle.h"
#include "VFD/VFDProtocol.h"

#include "Machine/MachineConfig.h"
#include "Protocol.h"  // rtAlarm
#include "Report.h"    // hex message
#include "Configuration/HandlerType.h"

#include <freertos/task.h>
#include <freertos/queue.h>
#include <atomic>

namespace Spindles {
    // number of commands that can be queued up.
    const int VFD_RS485_QUEUE_SIZE = 10;

    // ================== Class methods ==================================

    void VFDSpindle::init() {
        _sync_dev_speed = 0;
        _syncing        = false;

        // The following lets you have either a uart: section below the VFD section,
        // or "uart_num: N" referring to an externally defined uartN: section - but not both
        if (_uart) {
            _uart->begin();
        } else {
            _uart = config->_uarts[_uart_num];
            if (!_uart) {
                log_error("VFDSpindle: Missing uart" << _uart_num << " section");
                return;
            }
        }

        if (!_uart->configured()) {
            log_error("VFDSpindle: uart:" << _uart_num << " failed configuration");
            return;
        }

        if (_uart->setHalfDuplex()) {
            log_info("VFD: RS485 UART set half duplex failed");
            return;
        }

        // These VFDs are always reversible, but most can be set via the operator panel
        // to only allow one direction.  In principle we could check that setting and
        // automatically set is_reversable.
        is_reversable = true;

        _current_state = SpindleState::Disable;

        // Initialization is complete, so now it's okay to run the queue task:
        if (!VFD::VFDProtocol::vfd_cmd_queue) {  // init can happen many times, we only want to start one task
            VFD::VFDProtocol::vfd_cmd_queue   = xQueueCreate(VFD_RS485_QUEUE_SIZE, sizeof(VFD::VFDProtocol::VFDaction));
            VFD::VFDProtocol::vfd_speed_queue = xQueueCreate(VFD_RS485_QUEUE_SIZE, sizeof(uint32_t));

            xTaskCreateAffinitySet(VFD::VFDProtocol::vfd_cmd_task,  // task
                                    "vfd_cmdTaskHandle",             // name for task
                                    4096,                            // size of task stack
                                    this,                            // parameters
                                    1,                               // priority
                                    (1 << SUPPORT_TASK_CORE),        // affinity mask
                                    &VFD::VFDProtocol::vfd_cmdTaskHandle
            );
        }

        init_atc();
        config_message();

        set_mode(SpindleState::Disable, true);
    }

    void VFDSpindle::config_message() {
        std::string usage(" Spindle");
        usage += atc_info();
        _uart->config_message(name(), usage.c_str());
    }

    void VFDSpindle::set_mode(SpindleState mode, bool critical) {
        _last_override_value = sys.spindle_speed_ovr();  // sync these on mode changes
        if (VFD::VFDProtocol::vfd_cmd_queue) {
            VFD::VFDProtocol::VFDaction action;
            action.action   = VFD::VFDProtocol::actionSetMode;
            action.arg      = uint32_t(mode);
            action.critical = critical;
            if (xQueueSend(VFD::VFDProtocol::vfd_cmd_queue, &action, 0) != pdTRUE) {
                log_info("VFD Queue Full");
            }
        }
    }

    void VFDSpindle::setState(SpindleState state, SpindleSpeed speed) {
        log_debug(name() << ": setState:" << uint8_t(state) << " SpindleSpeed:" << speed);
        if (sys.abort()) {
            return;  // Block during abort.
        }

        if (speed == 0 && _disable_with_zero_speed) {
            log_debug("Disabling because speed is 0");
            state = SpindleState::Disable;
        }

        bool critical = (state_is(State::Cycle) || state != SpindleState::Disable);

        uint32_t dev_speed = mapSpeed(state, speed);

        if (_current_dev_speed != dev_speed) {
            log_debug("setSpeed " << int(dev_speed));
            setSpeed(dev_speed);
        }

        if (_current_state != state) {
            log_debug("set_mode " << int(state));
            set_mode(state, critical);  // critical if we are in a job
            _current_state = state;
        }

        if (!detail_->use_speed_feedback()) {
            spindleDelay(state, speed);
            return;
        }

        _syncing = true;  // poll for speed

        auto minSpeedAllowed = dev_speed > _slop ? (dev_speed - _slop) : 0;
        auto maxSpeedAllowed = dev_speed + _slop;

        if (_debug > 1) {
            log_info("Syncing to " << int(dev_speed));
        }

        uint32_t   prev_sync_speed   = _sync_dev_speed;
        TickType_t last_change_ticks = xTaskGetTickCount();

        while ((_last_override_value == sys.spindle_speed_ovr()) &&  // skip if the override changes
               (_sync_dev_speed < minSpeedAllowed || _sync_dev_speed > maxSpeedAllowed)) {
            if (sys.abort()) {
                _syncing = false;
                return;
            }
            if (!xQueueReceive(VFD::VFDProtocol::vfd_speed_queue, &_sync_dev_speed, 3000)) {
                mc_critical(ExecAlarm::SpindleControl);
                log_error(name() << ": spindle did not reach device units " << dev_speed << ". Reported value is " << _sync_dev_speed);
                _syncing = false;
                return;
            }

            if (_sync_dev_speed == prev_sync_speed) {
                if ((xTaskGetTickCount() - last_change_ticks) >= pdMS_TO_TICKS(3000)) {
                    break;  // speed has not changed for 3 seconds; give up waiting
                }
            } else {
                last_change_ticks = xTaskGetTickCount();
                prev_sync_speed   = _sync_dev_speed;
            }
        }
        _last_override_value = sys.spindle_speed_ovr();
        _current_speed       = speed;
        if (_debug > 1) {
            log_info("Synced speed to " << int(dev_speed));
        }

        _syncing = false;
    }

    void IRAM_ATTR VFDSpindle::setSpeedfromISR(uint32_t dev_speed) {
        if (_current_dev_speed == dev_speed || _last_speed == dev_speed) {
            return;
        }

        _last_speed = dev_speed;

        if (VFD::VFDProtocol::vfd_cmd_queue) {
            VFD::VFDProtocol::VFDaction action;
            action.action   = VFD::VFDProtocol::actionSetSpeed;
            action.arg      = dev_speed;
            action.critical = (dev_speed == 0);
            // Ignore errors because reporting is not safe from an ISR.
            // Perhaps set a flag instead?
            xQueueSendFromISR(VFD::VFDProtocol::vfd_cmd_queue, &action, 0);
        }
    }

    void VFDSpindle::setSpeed(uint32_t dev_speed) {
        if (VFD::VFDProtocol::vfd_cmd_queue) {
            VFD::VFDProtocol::VFDaction action;
            action.action   = VFD::VFDProtocol::actionSetSpeed;
            action.arg      = dev_speed;
            action.critical = dev_speed == 0;
            if (xQueueSend(VFD::VFDProtocol::vfd_cmd_queue, &action, 0) != pdTRUE) {
                log_info("VFD Queue Full");
            }
        }
    }

    void VFDSpindle::validate() {
        Spindle::validate();

        Assert(_uart != nullptr || _uart_num != -1, "VFD: missing UART configuration");
    }

    void VFDSpindle::afterParse() {
        detail_->afterParse();
    }

    void VFDSpindle::group(Configuration::HandlerBase& handler) {
        // RS485/Modbus-controlled VFD (Variable Frequency Drive) spindle. Shares a
        // uartN: section like any other UART consumer (uart_num:), or -- legacy form,
        // still supported -- can nest its own uart: subsection directly.
        if (handler.handlerType() == Configuration::HandlerType::Generator) {
            if (_uart_num == -1) {
                handler.section("uart", _uart, 1);
            } else {
                // @config uart_num
                // @default -1
                // @default_note not configured
                // Which top-level uartN: section this VFD's Modbus link runs over.
                handler.item("uart_num", _uart_num);
            }
        } else {
            handler.section("uart", _uart, 1);
            // @config uart_num
            // @default -1
            // @default_note not configured
            // Which top-level uartN: section this VFD's Modbus link runs over.
            handler.item("uart_num", _uart_num);
        }

        // @config modbus_id
        // @default 1
        // @tuning typical
        // Modbus slave address of the VFD -- must match the VFD's own configured value
        // (per https://modbus.org/docs/PI_MBUS_300.pdf). When in doubt, try 1.
        handler.item("modbus_id", _modbus_id, 0, 247);  // per https://modbus.org/docs/PI_MBUS_300.pdf

        // @config debug
        // @default 1
        // Debug message verbosity: 0-1 no debug info, 2 shows missing responses and speed
        // info, 3+ also shows raw Rx/Tx Modbus messages.
        handler.item("debug", _debug, 0, 5);

        // @config poll_ms
        // @default 250
        // How often, in milliseconds, to poll the VFD over Modbus for status/speed.
        handler.item("poll_ms", _poll_ms, 250, 20000);

        // @config retries
        // @default 5
        // Number of failed Modbus exchanges tolerated before raising an alarm.
        handler.item("retries", _retries);

        Spindle::group(handler);
        Spindle::groupDelaySettings(handler);
        detail_->group(handler);
    }

    // Called from the step ISR in place of a virtual dispatch, which would have
    // to read this class's vtable out of flash.  IRAM_ATTR, and the qualified
    // call keeps it non-virtual.
    static void IRAM_ATTR vfdspindle_speed_thunk(Spindle* s, uint32_t dev_speed) {
        static_cast<VFDSpindle*>(s)->VFDSpindle::setSpeedfromISR(dev_speed);
    }
    Spindle::IsrSpeedFn VFDSpindle::isr_speed_fn() {
        return vfdspindle_speed_thunk;
    }
}
