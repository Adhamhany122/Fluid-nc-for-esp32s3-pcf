#include "Buzzer.h"

#include "Machine/MachineConfig.h"
#include "Driver/PwmPin.h"
#include "Logging.h"

#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <cstdint>

namespace {

    struct ToneRequest {
        uint32_t frequency_hz;
        uint32_t duration_ms;
    };

    struct Note {
        uint32_t freq_hz;
        uint32_t duration_ms;
        uint32_t gap_ms;  // silence after this note, before the next
    };

    // "di-di-dit, di-di-dit" -- two quick rising three-note phrases.
    constexpr Note kStartupMelody[] = {
        { 523, 90, 30 },    // C5
        { 659, 90, 30 },    // E5
        { 784, 140, 120 },  // G5 -- held slightly longer, then a short pause before phrase 2
        { 659, 90, 30 },    // E5
        { 784, 90, 30 },    // G5
        { 1047, 180, 0 },   // C6
    };
    constexpr size_t kStartupMelodyLen = sizeof(kStartupMelody) / sizeof(kStartupMelody[0]);

    QueueHandle_t s_queue = nullptr;
    PwmPin*       s_pwm   = nullptr;

    void playTone(uint32_t freq_hz, uint32_t duration_ms) {
        if (!s_pwm || freq_hz == 0) {
            vTaskDelay(pdMS_TO_TICKS(duration_ms));
            return;
        }
        s_pwm->setFrequency(freq_hz);
        s_pwm->setDuty(s_pwm->period() / 2);  // ~50% duty -- a clean tone, not a max-volume square spike
        vTaskDelay(pdMS_TO_TICKS(duration_ms));
        s_pwm->setDuty(0);
    }

    void buzzerTask(void* arg) {
        bool play_startup_melody = (bool)(uintptr_t)arg;

        if (play_startup_melody) {
            for (size_t i = 0; i < kStartupMelodyLen; ++i) {
                playTone(kStartupMelody[i].freq_hz, kStartupMelody[i].duration_ms);
                if (kStartupMelody[i].gap_ms) {
                    vTaskDelay(pdMS_TO_TICKS(kStartupMelody[i].gap_ms));
                }
            }
        }

        // After the startup melody (or immediately, if it was skipped) this
        // task becomes a general-purpose tone player: any module can call
        // Buzzer::beep() -- e.g. PowerLossRecovery sounding a short alert
        // when it puts the "Resume job?" prompt on the OLED -- without
        // blocking its own task for the tone's duration.
        ToneRequest req;
        for (;;) {
            if (xQueueReceive(s_queue, &req, portMAX_DELAY) == pdTRUE) {
                playTone(req.frequency_hz, req.duration_ms);
            }
        }
    }
}

namespace Buzzer {
    void beep(uint32_t frequency_hz, uint32_t duration_ms) {
        if (!s_queue) {
            return;  // No buzzer: section configured, or init() hasn't run yet -- silently do nothing
        }
        ToneRequest req { frequency_hz, duration_ms };
        xQueueSend(s_queue, &req, 0);  // Never block the caller; drop the request if the queue is backed up
    }
}

void BuzzerModule::group(Configuration::HandlerBase& handler) {
    // @config output_pin
    // @default NO_PIN
    // @pin_attributes output
    // GPIO driving the buzzer. A passive piezo buzzer (two leads, no internal
    // oscillator) is expected -- it is driven directly by this PWM tone, unlike an
    // active buzzer module which only needs a DC level and has no pitch control.
    handler.item("output_pin", _outputPin);

    // @config startup_melody
    // @default true
    // Plays a short multi-tone chime once, immediately after this module initializes
    // (i.e. shortly after boot). Set false to keep the buzzer silent at boot while still
    // allowing other modules (e.g. the power-loss-recovery prompt) to request a beep.
    handler.item("startup_melody", _startupMelody);

    // @config enabled
    // @default true
    handler.item("enabled", _enabled);
}

void BuzzerModule::validate() {
    if (_enabled && _outputPin.undefined()) {
        log_config_error("buzzer: output_pin must be set when enabled");
        _error = true;
    }
}

void BuzzerModule::afterParse() {}

void BuzzerModule::init() {
    if (_error || !_enabled) {
        return;
    }

    _outputPin.setAttr(Pin::Attr::Output);
    pinnum_t gpio = _outputPin.getNative(Pin::Capabilities::Output);

    // Constructed at 800Hz -- roughly the middle of the melody's note range
    // -- purely so the LEDC timer's initial duty-resolution is calculated
    // against a representative frequency; setFrequency() (see PwmPin.h)
    // retunes the same channel for every note afterward.
    s_pwm = new PwmPin(gpio, false, 800);

    s_queue = xQueueCreate(4, sizeof(ToneRequest));

    xTaskCreatePinnedToCore(buzzerTask, "buzzer", 2560, (void*)(uintptr_t)_startupMelody, 1, nullptr, 1);

    log_info("Buzzer: output on gpio " << int(gpio));
}

void BuzzerModule::deinit() {}

ConfigurableModuleFactory::InstanceBuilder<BuzzerModule> __buzzer_module("buzzer");
