// Copyright (c) 2026 - Custom ESP32-S3 hardware integration
// Use of this source code is governed by a GPLv3 license that can be found in the LICENSE file.

// SH1106 driver for the OLEDDisplay base class (the same library FluidNC
// already depends on for SSD1306_I2C -- see platformio.ini lib_deps:
// "thingpulse/ESP8266 and ESP32 OLED driver for SSD1306 displays"). The
// OLEDDisplay base class is controller-agnostic: it owns the 1bpp
// framebuffer, fonts and drawing primitives, and leaves connect()/display()
// abstract for a subclass to push that framebuffer to real hardware. This
// mirrors SSD1306_I2C.{h,cpp} structurally but implements SH1106's own wire
// protocol, which differs in two ways that matter:
//
//  1. SH1106 has no horizontal/vertical addressing mode (no COLUMNADDR/
//     PAGEADDR commands). It only supports page addressing: select a page
//     (0xB0 | page), set the low and high nibbles of the column address
//     (0x00-0x0F, 0x10-0x17), then stream that page's bytes. SSD1306_I2C's
//     display() (which uses COLUMNADDR/PAGEADDR) will not work against this
//     chip, hence a separate class rather than a flag on the existing one.
//
//  2. SH1106 panels have 132 columns of GRAM but are wired to a 128-pixel
//     glass, so writes must be offset by the panel's column offset (commonly
//     2, sometimes 0 or 4 depending on the specific module) or the image
//     shifts sideways / wraps. This is exposed as a constructor parameter
//     rather than hardcoded, since it is a per-module characteristic.
#pragma once

#include <OLEDDisplay.h>
#include "Machine/I2CBus.h"

namespace Machine {
    class I2CBus;
}

class SH1106_I2C : public OLEDDisplay {
private:
    uint8_t          _address;
    Machine::I2CBus*  _i2c;
    uint32_t          _frequency;
    uint8_t           _columnOffset;
    bool              _error = false;

public:
    // columnOffset: GRAM column offset for this panel, typically 2. Most
    // common 1.3"/0.96" SH1106 modules use 2; a small minority use 0 or 4 --
    // if the image is shifted sideways by exactly that many pixels, change
    // it (see oled: sh1106_column_offset in the YAML config).
    SH1106_I2C(uint8_t address, OLEDDISPLAY_GEOMETRY g, Machine::I2CBus* i2c, uint32_t frequency, uint8_t columnOffset = 2);

    bool connect();
    void display(void);

    // Sends the full SH1106 power-up register sequence. The base
    // OLEDDisplay::init() (from the thingpulse SSD1306 library this class
    // otherwise reuses) is written against SSD1306 and may send that
    // chip's init commands internally before/around calling connect().
    // SH1106 registers are simple idempotent state (not a one-shot
    // sequencer), so sending this afterward leaves the panel in a known
    // good state regardless of what the inherited init() already did.
    // Call this once, right after _oled->init(), before the first display().
    void sendInitSequence();

private:
    int getBufferOffset(void);

    inline void sendCommand(uint8_t command) __attribute__((always_inline)) {
        if (_error) {
            return;
        }
        uint8_t data[2];
        data[0] = 0x80;  // Co=1, D/C=0 (control byte, one command follows)
        data[1] = command;
        if (_i2c->write(_address, data, sizeof(data)) < 0) {
            log_error("SH1106 OLED is not responding");
            _error = true;
        }
    }
};
