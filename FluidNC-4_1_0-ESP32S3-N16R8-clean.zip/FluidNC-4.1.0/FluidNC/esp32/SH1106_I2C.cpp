#include "SH1106_I2C.h"

using namespace Machine;

SH1106_I2C::SH1106_I2C(uint8_t address, OLEDDISPLAY_GEOMETRY g, I2CBus* i2c, uint32_t frequency, uint8_t columnOffset) :
    _address(address), _i2c(i2c), _frequency(frequency), _columnOffset(columnOffset), _error(false) {
    setGeometry(g);
}

bool SH1106_I2C::connect() {
    return true;
}

void SH1106_I2C::sendInitSequence() {
    sendCommand(0xAE);  // Display OFF while we configure it
    sendCommand(0xD5);  // Set display clock divide ratio / oscillator frequency
    sendCommand(0x80);
    sendCommand(0xA8);  // Set multiplex ratio
    sendCommand(0x3F);  // 1/64 duty (64-row panel)
    sendCommand(0xD3);  // Set display offset
    sendCommand(0x00);
    sendCommand(0x40);  // Set display start line = 0
    sendCommand(0xAD);  // SH1106 DC-DC control mode (NOT SSD1306's 0x8D charge pump)
    sendCommand(0x8B);  // DC-DC enabled
    sendCommand(0xA1);  // Segment re-map: column address 127 mapped to SEG0
    sendCommand(0xC8);  // COM output scan direction: remapped (top-to-bottom)
    sendCommand(0xDA);  // Set COM pins hardware configuration
    sendCommand(0x12);
    sendCommand(0x81);  // Set contrast control
    sendCommand(0x80);
    sendCommand(0xD9);  // Set pre-charge period
    sendCommand(0x1F);
    sendCommand(0xDB);  // Set VCOMH deselect level
    sendCommand(0x40);
    sendCommand(0x33);  // Set VPP (panel pump voltage); 0x33 = 9V, a safe common default
    sendCommand(0xA4);  // Resume RAM content display (not "entire display on")
    sendCommand(0xA6);  // Normal (non-inverted) display
    sendCommand(0xAF);  // Display ON
}

void SH1106_I2C::display(void) {
    if (_error) {
        return;
    }
    // SH1106 only supports page addressing mode -- there is no horizontal/
    // vertical auto-increment across pages like SSD1306's COLUMNADDR/
    // PAGEADDR commands provide, so each of the display's 8-pixel-tall
    // "pages" is addressed and written individually.
    const int x_offset = _columnOffset + (128 - this->width()) / 2;
    const int n_pages   = this->height() / 8;

    for (int page = 0; page < n_pages; page++) {
        sendCommand(0xB0 | (page & 0x0F));           // Set page address
        sendCommand(0x00 | (x_offset & 0x0F));        // Set lower column address nibble
        sendCommand(0x10 | ((x_offset >> 4) & 0x0F));  // Set higher column address nibble

        if (_error) {
            return;
        }

        // Each I2C transaction is prefixed with a control byte. buffer[-1]
        // is used as scratch for that control byte so the page's pixel
        // bytes can be sent in a single contiguous write, exactly as
        // SSD1306_I2C::display() does for its own transfers.
        uint8_t* start = &buffer[page * this->width() - 1];
        uint8_t  save  = *start;

        *start = 0x40;  // Co=0, D/C=1 (control byte, stream of data bytes follows)
        _i2c->write(_address, start, this->width() + 1);
        *start = save;
    }
}

int SH1106_I2C::getBufferOffset(void) {
    return 0;
}
