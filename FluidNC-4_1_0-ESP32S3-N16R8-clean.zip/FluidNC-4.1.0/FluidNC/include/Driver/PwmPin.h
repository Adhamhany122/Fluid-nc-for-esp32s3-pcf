// Copyright 2022 - Mitch Bradley
// Use of this source code is governed by a GPLv3 license that can be found in the LICENSE file.

#pragma once
#include "Config.h"
#include "Driver/fluidnc_gpio.h"
// PWM driver interface
#include <stdint.h>

class PwmPin {
public:
    PwmPin(pinnum_t gpio, bool invert, uint32_t frequency);
    ~PwmPin();
    uint32_t frequency() { return _frequency; }
    uint32_t period() { return _period; }

    void setDuty(uint32_t duty);

    // Changes the LEDC timer's output frequency without reallocating a
    // channel. ledc_set_freq() is a lightweight register write (it does not
    // touch the channel's gpio_matrix routing or duty latch), so this is
    // safe to call repeatedly at runtime -- e.g. a buzzer stepping through
    // the notes of a melody on a single permanently-allocated channel,
    // rather than exhausting the 4-independent-channel budget allocateChannel()
    // hands out by constructing a new PwmPin per note.
    void setFrequency(uint32_t frequency);

private:
    pinnum_t _gpio;
    uint32_t _frequency;
    objnum_t _channel;
    uint32_t _period;
};
